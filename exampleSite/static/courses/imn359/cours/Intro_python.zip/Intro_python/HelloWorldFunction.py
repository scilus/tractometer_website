
def HelloWorldFunction():
    print('Hello World!')
