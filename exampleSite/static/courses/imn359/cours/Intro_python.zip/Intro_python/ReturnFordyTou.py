
def ReturnFordyTou(aDoReturn):
    #Returns 42 if aDoReturn equals true, 0 otherwise
    if aDoReturn == 1:
        return 42
    else:
        return 0
