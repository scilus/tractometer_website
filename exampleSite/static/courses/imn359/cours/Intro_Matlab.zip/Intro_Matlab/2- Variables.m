clear;

% 2.0 - Variables
%
%   Sous matlab, les variables sont faiblement typ�es et n'ont pas besoin
%   d'�tre explicitement initialis�e. Il est donc possible de simplement
%   ajouter une nouvelle variable (sortie de nulle part) en plein milieu
%   d'une s�quence de commande et cette derni�re sera allou�e. 
%
%   Matlab poss�de quelques types de base mais ces derniers sont
%   habituellement abstraits pour rester simple et transparents. Les
%   diff�rences principales se situent au niveau des variables de type
%   num�rique et des variables textuelles, la plupart des types de variable
%   sont compatible � l'exception du passage implicite num�rique/texte ou
%   inversement.
%
%   Parmi les types support�s, on note les complexes, les entiers, les
%   variables symboliques, les r�els, etc.
%
%   Pour cr�er une variable, on peut simplement assigner une valeur � un
%   nom.

var1 = 3.14

chaineDeTexte = 'Salut la plan�te!'

%   La seule contrainte pour les noms de variable est que ces derni�res
%   doivent commencer par une lettre. Par la suite, n'importe quelle
%   combinaison de lettre ou de '_' peuvent �tre utilis�es.
%
%   *IMPORTANT* : Les variables matlab suivent la casse, la variable "var1"
%   ne serait donc pas identique � la variable "Var1".

var1 = 3;
Var1 = 2;

var1
Var1

% 2.1 - Variable pr�d�finies
%
%   Matlab poss�de certaines variables ou mots-cl�s pr�d�finis qui peuvent 
%   �tre utilis�s � tout moment. 
%
%   - i et j sont utilis�s pour d�signer des nombres complexes
%   - pi est une constante (3.1415926...)
%   - ans garde la derni�re valeur assign�e ou retourn�e
%   - Inf et -Inf sont respectivement l'infini et l'infini n�gatif.
%   - NaN = Not a Number
%
%   *IMPORTANT* N'utilisez pas i et j pour les boucles for!

3+4i
pi
3+12
ans
Inf
NaN

% 2.2 - Variables scalaires (valeur num�rique)
%
%   Une variable peut �tre donn�e une valeur explicitement.

a = 10

%   Une variable peut aussi avoir une valeur explicitement d�finie comme
%   �tant le r�sultat d'une fonction utilisant des valeurs connues.

c = 1.3 * 45 - 2 * a

%   Pour que matlab n'affiche pas la valeur de retour � chaque commande,
%   ajoutez un ";" � la fin de votre ligne de commande.

booya = 13/3;

% 2.3 - Tableux, Matrices et Vecteur
%   
%   Sous Matlab, il existe, comme dans plusieurs langages de programmation,
%   la notion de tableau ou de matrice. Cette structure est en fait la
%   force de matlab puisque Matlab (Matrix Laboratory) est optimis� pour
%   les calculs sur de grosses s�ries de donn�es contenues dans des
%   tableaux.
%
%   Notons que sous matlab, une matrice ou un vecteur sont tous deux
%   consid�r�s comme �tant des tableaux.
%
%   Il existe aussi une structure de tableau par cellule (cell) mais cette
%   structure de donn�e est plus avanc�e et ne sera pas couverte dans notre
%   introduction.

% 2.3.1 - Vecteur Ligne
%
%   Un vecteur ligne se d�fini � l'aide des crochets rectangulaires. Les
%   valeurs du vecteur sont list�es et s�par�es par des espaces ou des
%   virgules.

row = [1 2 5.4 -6.6]
row = [1, 2, 3, 5.4, -6.6]%  Regardez la variable dans le workspace!



% 2.3.2 - Vecteur colonne
%
%   Matlab fait une diff�rence entre les vecteurs ligne et vecteurs
%   colonnes. Assurez-vous donc que ces derniers sont clairement d�fini.
%  
%   Pour changer de colonne dans un vecteur ou une matrice sous matlab, on
%   utilise le caract�re ";" dans la d�finition du vecteur ou de la
%   matrice. Par exemple :

column = [1; 4; 10.2; -5]% Regardez la variable dans le workspace!

% 2.3.3 - Taille d'un vecteur
%
%   La taille d'un vecteur peut �tre obtenue via la fonction
%   "size(vecteur". En fait, size peut retourner la taille de n'importe
%   quel variable num�rique. 
%
%   La taille retourn�e est un vecteur � 2 dimensions sous la forme
%   "largeur hauteur".

size(row)

size(column)

size(25)

size([10 2])

%   Si vous souhaitez uniquement avoir la longueur du vecteur, vous pouvez
%   aussi utiliser la fonction "length", vous ne pourrez cependant plus
%   faire la diff�rence entre un vecteur ligne ou colonne

length(row)
length(column)

% 2.3.4 - Matrices
%
%   La cr�ation d'une matrice est tr�s similaire � la cr�ation d'un
%   vecteur, except� qu'on combine ici la notion de ligne et de colonne.
%   Par exemple, pour faire une matrice 2x2, on utiliserait le code suivant
%   :

a = [1 2; 3 4]

%   Les �l�ments 1 et 2 �tant sur la premi�re ligne, on les s�pare par un
%   espace. Pour indiquer � matlab qu'on d�bute une nouvelle ligne, on
%   �crit un ";" puis ensuite les �l�ments de la 2e ligne.
%
%   Il est aussi possible de concat�ner des vecteurs ou des matrices
%   ensemble, en utilisant la m�me synthaxe.

a = [1 2];
b = [3 4];
c = [5;6];

d = [a;b];
e = [d c];
f = [[e e]; [a b a]]; %Holy poop, �a commence � devenir compliqu�!

str = ['Hello, I am ' 'The King of the World']

% 2.4 - save/clear/load
%
%   Lorsque vous travaillez sur matlab, il peut �tre utilise de sauvegarder
%   la valeur d'une variable sur le disque afin de la r�utiliser dans une
%   session de travail subs�quente, ou de vouloir enlever la variable du
%   workspace pour lib�rer de la m�moire. Le tout s'effectuer via les
%   commandes save, clear et load.
%   
%   Chaque commande peut �tre utilis�e en lui passant le nom des variables
%   sur la/lesquelles effectuer l'action. Il est aussi possible d'appliquer
%   l'action � toutes les variables en entrant aucun nom de variable � la
%   suite de l'action.
%
%   Finalement, il est possible de sp�cifier un nom de fichier particulier
%   pour les commandes "load/save" Le nom de fichier s'�crit comme premier
%   param�tre dans un tel cas.

save 'SuperTest' str
clear str
load 'SuperTest'

save
load 

clear a b
clear