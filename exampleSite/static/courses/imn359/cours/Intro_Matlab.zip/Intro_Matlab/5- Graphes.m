% 5.0 - Affichage de graphes
%
%   L'affichage de graphe est un outil puissant de matlab, mais
%   relativement simple � utiliser lorsqu'on souhaite avoir un graphe
%   relativement g�n�ral sans configuration particuli�re.
%
%   Il est possible de g�n�rer le graphique d'un vecteur en fonction de ses
%   indexes, par exemple :

vec = [1 2 3 0 0 2];
plot(vec)

%   On peut faire dem�me mais en sp�cifiant sp�cifiquement les valeurs sur
%   Y et les valeurs sur X � utiliser. Par exemple :

x = linspace(0,4*pi,10);
y = sin(x);

plot(y) %sans sp�cifier X

plot(x,y); %en sp�cifiant X (regardez l'axe X, les valeurs sont diff�rentes.)

%   Notons que la fonction "plot" g�n�re un point � chaque paire (x,y) puis
%   relis ces points avec une ligne. Pour qu'un graphe soit plus "lisse",
%   on peut augmenter le nombre de point.

x = linspace(0,4*pi,1000);
y = sin(x);
plot(x,y)

%   Dans ce contexte, faites attention! X et Y doivent �tre de la m�me
%   taille sinon matlab produira une erreur.

% 5.1  - Configuration des options d'affichage.
%
%   Sans entrer trop dans le d�tail, notons qu'il est possible de
%   configurer l'affichage de votre graphe. Par exemple, il est possible de
%   configurer le trait du graph avec un code relativement simple o� on
%   indique la couleur, le type de point et le type de ligne � afficher.

plot(x,y,'green.-') %Afficher les points et la ligne en vert.
plot(x,y,'red.') %Afficher seulement les points en rouge.

%   Les options de configuration sont beaucou plus avanc�es en r�alit�,
%   pour les voir, allez regarder l'aide :). (doc line_props)

plot(x,y,'--s','LineWidth',2,'Color',[1 0 0],'MarkerEdgeColor','black',... 
    'MarkerFaceColor','green','MarkerSize',10);

%   (Remarquez l'utilisation d'un "..." pour indiquer que la commande se
%   poursuit sur la ligne suivante.

% 5.2 - Gradation non lin�aire
%
%   Il est possible d'utiliser "semilogx", "semilogy" ou "loglog" pour
%   g�n�rer un graphe avec des �chelles logarithmiques.

x = -pi:pi/100:pi;
y = cos(4*x).*sin(10*x).*exp(-abs(x));
plot(x,y,'k-');

semilogx(x,y,'k');
semilogy(y,'r.-');
loglog(x,y);

%   Un exemple assez �vident pour les sceptiques :

x = 0:100;
y = exp(x);

semilogy(x,y,'k.-');

% 5.3 - Graphes en 3D
%
%   Pourquoi s'arr�ter � deux dimension? Suivant la m�me formulation, on
%   peut aussi cr�er un graphe 3D en ajoutant une 3e dimension et en
%   utilisant la fonction "plot3"
%

time = 0:0.001:4*pi;
x = sin(time);
y = cos(time);
z = time;
plot3(x,y,z,'k','LineWidth',2);
zlabel('Time'); % <- utile pour renommer les axes!

% 5.4 - Visualiser une matrice
%
%   Une matrice peut �tre visualis�e comme une grille de valeurs 2D en
%   utilisant la fonction "imagesc)
%

mat = rand(64);
imagesc(mat);
colorbar

%   Vous pouvez aussi charger une image et l'afficher! L'image est en fait
%   une matrice 2D.

mat = imread('lena.bmp');
imagesc(mat);
axis square; %<- On ajoute cette ligne pour s'assurer que les 2 axes ont la m�me longueur � l'�cran.

%   Pour �viter d'avoir un arc-en-ciel de couleur, on peut mettre la carte
%   de couleur � quelque chose de plus intuitif
 
colormap(gray) %cartes de couleur disponibles : mat, gray, cool, hot, jet

% 5.4 - Graphes de surfaces 3D
%  
%   Il est aussi possible d'afficher des graphes en 3D sous forme de
%   surfaces tridimensionnelles. On utilise la fonction "meshgrid" qui nous
%   g�n�re  nos points en X et en Y.

x = -pi : 0.1 : pi;
y = -pi : 0.1 : pi;

[X,Y] = meshgrid(x,y);

Z = sin(X).*cos(Y);

surf(X,Y,Z);
surf(x,y,Z);

%   En utilisant la fonction "contour" on peut g�n�rer les iso-contours de
%   notre surface 3D.

contour(X,Y,Z,'LineWidth',2);
hold on;
mesh(X,Y,Z);
