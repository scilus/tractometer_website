function [ returnVal ] = ReturnFordyTou( aDoReturn )
%RETURNFORDYTOU Returns 42 if aDoReturn equals true, 0 otherwise

if(aDoReturn == 1)
    returnVal = 42;
else
    returnVal = 0;
end


end

