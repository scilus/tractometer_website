% 6.0 - Fonctions personnalis�es
%
%   Matlab poss�de aussi son propre langage de programmation. Qui dit
%   langage de programmation dit donc fonctions personnalis�es.
%
%   La signature de fonction se donne telle que :
%   
%   function [out1,out2,out3,etc] = funName(in1,in2)
%
%   La fonction peut �tre plac�e dans un fichier ".m" ayant un nom de
%   fichier identique au nom de la fonction.
%
%   Une fonction n'a pas besoin de valeur de retour, il suffit simplement
%   d'assigner les valeurs souhait�es au variables dans le vecteur de
%   retour.
%
%   Toutes les variables d�finies dans la fonction ont une port�e ne
%   d�passant pas cette derni�re.
%
%   Notons finalement qu'il est possible de surcharger des fonctions
%   d�finies sous matlab.

HelloWorldFunction()
value = ReturnFordyTou(false)
value = ReturnFordyTou(true)

% 6.1 - Structures de contr�le logique
%
%   Matlab poss�de des structures de contr�les logique propre � ce
%   qu'on retrouve habituellement dans un langage de programmation. La
%   syntaxe change l�g�rement par contre par rapport au C++
%
%   IF :
%
%   if condition
%       commandes
%   end
%   
%
%   ELSE :
%
%   if condition
%       commandes1
%   else
%       commandes2
%   end
%
%
%   ELSEIF:
%
%   if condition1
%       commandes1
%   elseif condition2
%       commandes2
%   else
%       commandes3
%   end
%
%   Matlab peut aussi faire des boucles "for". Dans ce cas-ci, il n'y a pas
%   de variable incr�ment�e explicitement � chaque fois, on passe plut�t un
%   vecteur � la boucle for :
%
%   for n=1:100
%       commandes
%   end
%
%   Les formulations d'initialisation vues pr�c�demment fonctionnent aussi.
%
%   for n=1:2:100
%       commandes
%   end
%
%   Finalement, Matlab supporte aussi la structure de contr�le "WHILE".
%
%   while condition
%       commandes
%   end

% 6.2 - Op�rateurs relationels
%
%   Comme tout langage de programmation, matlab poss�de aussi des
%   op�rateurs pour �valuer les relations entre les valeurs. Ces op�rateurs
%   retournent z�ro (faux) ou une valeur non z�ro (vrai).
%
%
%   Op�rateurs relationels : 
%
%   == �gal
%   ~= non �gal
%   >  plus grand que
%   <  plus petit que
%   >= plus grand ou �gal
%   <= plus petit ou �gal
%
%   Sous matlab, la notion de bool�en n'existe pas explicitement. Tel
%   qu'expliqu� plus haut, une valeur � z�ro veut dire faux (false) et une
%   valeur non z�ro signifie vrai (true)
%
%   Les op�rateurs logiques utilisent donc ce fonctionnement pour
%   d�terminer si oui ou non une expression bool�ene est vraie ou fausse.
%
%   Op�rateurs logiques
%   &   And
%   |   Or
%   ~   Not
%   Xor Xor
%

boolTest = 1 & 1
boolTest = 1 & 0
boolTest = 1 | 0
boolTest = 1 & ~0
