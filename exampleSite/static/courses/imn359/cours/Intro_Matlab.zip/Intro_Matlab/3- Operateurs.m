% 3.0 - Op�rations math�matiques
%
%   Matlab supporte les op�rations arithm�tiques standards. 
%
%   - op�rations de base (+,-,*,/)
%   - expontenielle (^)
%   - parenth�se pour grouper des expressions
%   
% *IMPORTANT* Les multiplications ne sont PAS implicites.

7/45
(1+i) * (2+i)
1/0
0/0

4^2
(3+4*j)^2

((2+3)*3)^0.1

3(1+0.7) % FAIL!

% Et pour lib�rer la fen�tre de commande, utilisez :

clc


% 3.1 - Fonctions fournies avec matlab
%
%   Matlab poss�de une quantit� faramineuse de fonctions math�matiques
%   fournies par d�faut.

sqrt(2)
log(2)
log10(0.23)
cos(1.2)
atan(-0.8)
exp(2+4*i)
round(1.4)
floor(3.3)
ceil(3.3)
abs(1+i)

%   Regardez la documentation pour voir quelles fonctions sont disponibles!
%   Gardez cependant en t�te que certaines fonctions n�cessitent des
%   extensions sp�ciales � Matlab. Nous avons plusieurs extensions �
%   l'universit� mais certaines pourraient ne pas y �tre.

% 3.2 - Transpos�e
%
%   L'op�ration de transposition est utile pour transposer une matrice ou
%   un vecteur (vecteur ligne devient vecteur colonne et inversement)
%
%   Matlab peut faire une transpos�e hermitienne avec l'op�rateur "'".
%   Notez que la transpos�e hermitienne appliqu�e sur des nombres
%   complexes transpose et conjuge le nombre. Pour �viter le conjugu�,
%   utilis� l'op�rateur ".'".
%
%   Finalement, vous pouvez aussi utiliser la fonction "transpose"
%   directement qui prend le vecteur ou la matrice en param�tre.

a = [1 2 3 4+i]
transpose(a)
a'
a.'

% 3.3 - Addition/Soustraction de vecteurs/matrices
%
%   Il est possible d'ajouter ou de soustraire des vecteurs ou des matrices
%   si ces derniers ont la m�me dimension. L'adition se fait �l�ment par
%   �l�ment. Il est aussi possible de trouver la somme ou le produit de
%   tous les �l�ments d'un vecteur ou d'une matrice via les fonctions "sum"
%   et "prod".

a = [12 3 32 -11]
b = [2; 11; -30; 32;]

c = a + b'

c = a' + b

s = sum(a)
p = prod(a)

% 3.4 - Fonctions "element-wise"
%
%   Toutes les fonctions de Matlab ou presque qui fonctionnent sur un
%   scalaire seul peuvent aussi fonctionner sur une matrice ou un vecteur. 
%
%   Si jamais une fonction ne semble pas compatible avec un vecteur,
%   n'h�sitez-pas � consulter la documentation, la compatibilit� avec les
%   types y sera inscrite.
%

t = [-1 -2 3];

f = exp(t)
f = abs(t)

% 3.5 - Op�rateurs � deux modes
%
%   Certains op�rateurs sous matlab poss�dent deux modes de fonctionnement,
%   soit un mode de fonctionnement global et un mode �l�ment par �l�ment.
%
%   L'op�rateur en mode �l�ment par �l�ment doit �tre pr�c�d� d'un point.
%   L'op�rateur en mode global est utilis� directement.
%  
%   Les op�rateurs ayant 2 modes sont : *, / et ^
%
%   Les tailles doivent concorder pour les op�rateur selon s'ils sont
%   globaux ou �l�ment par �l�ment.

a = [1 2];
b = [3 4];

a * b' %Produit scalaire (mode global)
a .* b %�l�ment par �l�ment

% 3.6 - Initialisation automatique
%
%   Il est courant sous Matlab de vouloir initialiser des grosses matrices
%   avec une valeur par d�faut ou une s�quence num�rique r�guli�re. Pour
%   ceci, matlab pr�voit certaines fonctions d'initialisation, soit "ones",
%   "zeros", "rand", "nan".
%
% Ces fonctions initialisent une matrice ou un vecteur contenant des
% valeurs analogues � leur nom. Elles prennent 2 param�tre, soit la taille
% de la matrice ou du vecteur en hauteur et en largeur (dans cet ordre).

o = ones(1,10)  %Vecteur ligne avec 10 �l�ments � 1
z = zeros(23,1) %Vecteur colonne avec 23 �l�ments � 0
r = rand(1,45)  %Vecteur ligne de 45 �l�ments initialis�s al�atoirement entre 0 et 1.
n = nan(1,10)   %... vecteur ligne de 10 �l�ments cass�s. Jsais pas trop pourquoi quelqu'un voudrait faire �a.

% Le tout fonctionne naturellement aussi avec des matrices

o = ones(10) %Matrice 10x10 de 1 (On remarque ici qu'on a utilis� 1 seul param�tre)
z = zeros(23,3) %Matrice 23x3 de 0

% 3.7 - Initialisation automatique de s�quences
%
%   Tel qu'expliqu� au point pr�c�dent, il est aussi possible d'initialiser
%   des s�quences de nombre qui suivent un incr�ment particulier. Par
%   exemple, on peut d�finir une s�quence sous la forme "valeur initiale :
%   valeur d'incr�ment : valeur finale".
%
b = 0 : 2 : 10
b = [ 0 : 2 : 10] %identique
 
b = [10 : -2 : 0] %d�croissant
 
%  Il est possible d'omettre l'incr�ment, dans quel cas il sera � 1 par
%  d�faut.
 
b = [1 : 10]
 
% Une formulation alternative � la formulation avec les ":" est
% l'utilisation de la fonction linspace(d�but,fin,nbvaleurs)
 
a = linspace(0,10,6)
b = 0 : 2 : 10
 
% Pour avoir des incr�ments logarithmiques, on peut aussi utiliser la
% fonction "logspace". La formulation avec ":" ne premet pas les
% incr�ments logarithmiques. La fonction logspace(X1,X2,N) g�n�re N points
% �galement espac�s sur une �chelle logarithmique entre 10^X1 et 10^X2

c = logspace(2,4,10)
 
 




