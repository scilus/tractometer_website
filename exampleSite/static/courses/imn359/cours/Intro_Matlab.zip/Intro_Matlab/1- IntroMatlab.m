%%%%%%%%%%%%%%%%%%% INTRODUCTION %%%%%%%%%%%%%%%%%%%
% IMN359
% Programmation sous matlab
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 1.0 - Workspace, Historique des commandes, Fen�tre de commande, vue du
% syst�me de fichier
%
%   Sous Matlab, le Workspace, situ� en haut � droite de la fen�tre
%   est l'emplacement indiquant les variables d�clar�es ainsi que 
%   leur valeur. Il est possible de visualiser, modifier, sauvegarder ou 
%   supprimer des variables � partir de cet emplacement. Notons que le
%   workspace permet de visualiser les valeurs des variables courantes �
%   tout moment lors de l'ex�cution de code Matlab. Il est donc possible de
%   visualiser les valeurs de variables � l'int�rieur de boucles ou de
%   fonctions.
%
%   L'historique des commandes est une sous-fen�tre permettant de
%   visualiser les commandes pr�c�demments entr�es pour facilement pouvoir
%   les rappeller par la suite. Cette sous-fen�tre est situ�e sous la
%   fen�tre du workspace.
%
%   La fen�tre de commandes quant � elle est le principal emplacement de
%   travail sous matlab. C'est dans cette fen�tre que vous entrez les
%   diverses commandes. La fen�tre de commande est situ�e au milieu de
%   l'�cran.
%
%   Finalement, la vue du syst�me de fichier, situ�e en haut � droite,
%   permet de voir le r�pertoire courant et les fichiers et
%   sous-r�pertoires qu'il contient.
%

% 1.1 - Organisation du travail avec les r�pertoires
%
%   Matlab peut acc�der directement au syst�me de fichier de l'ordinateur
%   afin d'y lire et �crire des donn�es ou aller chercher des fonctions
%   externes d�finies par l'utilisateur. Dans cette optique, matlab poss�de
%   un r�pertoire de travail courant � partir duquel les chemins sont
%   relatifs. Pour conna�tre le r�pertoire de travail courant, vous pouvez
%   simplement entrer la commande unix "pwd" (pour "Print Working
%   Directory") qui affichera le tout. Vous pouvez aussi avoir acc�s au
%   chemin via l'entr�e "Current Folder". 
%
%   Sur une autre note, le r�pertoire de travail peut �tre modifi� en
%   utilisant les commandes unix de syst�me de fichier habituelles
%   (cd, rm, mv, etc.)
%   
%   IMPORTANT : �viter � tout prix d'utiliser des espaces dans vos noms de
%   dossier ou de fichier. Matlab ne g�re pas tr�s bien les espaces.

pwd
cd ..
pwd
cd 'Intro_Matlab'   

% 1.2 - Documentation et aide
%
%   La documentation de matlab est extr�mement compl�te et facile
%   d'utilisation. Les fonctionnalit�s de matlab peuvent �tre acc�d�es via
%   la commande "help" qui affichera un texte d'aide rapide, ou via la
%   commande "doc" qui affichera une fen�tre d'aide html plus compl�te.
%
%   Pour utiliser les commandes "help" et "doc", il faut simplement entrer
%   la commande en la suivant du mot cl� ou de la fonction de matlab pour
%   laquelle on souhaite avoir de l'information. Il est aussi possible
%   d'entrer "doc" ou "help" sans aucun nom de fonction pour ouvrir l'aide
%   � sa racine.

help
help sin
doc
doc sin

% 1.3 - Scripts
%
%   Il est possible d'entrer toutes les op�rations � effectuer dans la
%   fen�tre de matlab directement. Ceci �tant dit, le tout devient
%   relativement complexe � g�rer lorsque plusieurs commandes doivent �tre
%   entr�es les unes � la suite des autres. Une m�thode plus efficace pour
%   bien organiser le travail est d'entrer les commandes � ex�cuter dans un
%   script puis demander l'ex�cution d'un script. Le fichier courant par
%   exemple est un script Matlab. 
%
%   Les scripts Matlab ont habituellement l'extention ".m" et sont des
%   documents textuels contenant des commandes Matlab. Pour ex�cuter un
%   script, simplement appeller le nom du fichier sans l'extension.
%   Assurez-vous cependant que le fichier est bien situ� dans le r�pertoire
%   courant!
%
%   Il est aussi possible d'ouvrir un �diteur de texte pour modifier le
%   script. Ceci peut �tre fait via la commande "edit" et en entrant le nom
%   du fichier � �diter, ou en double-cliquant directement sur celui-ci
%   dans la vue du syt�me de fichiers.

edit Exemples/Script1.m

Exemples/Script1 %Fait une erreur
cd Exemples
Script1 % Fonctionne!
cd ..

% 1.4 - Commentaires
%
%   Tout les caract�res situ�s apr�s un caract�re "%" sous Matlab sont
%   consid�r� des commentaires et ne sont pas ex�cut�s. Ce que vous lisez
%   pr�sentement est un commentaire.
