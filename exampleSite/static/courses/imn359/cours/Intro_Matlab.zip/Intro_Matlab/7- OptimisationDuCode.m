% 7.0 - Optimisation du code matlab
%
%   Tel que bri�vement expliqu� plus t�t, le code matlab est hautement
%   optimis� pour travailler directement sur des matrices et des vecteurs.
%   Il est donc beaucoup plus performant d'effectuer des op�rations
%   globales sur des vecteurs plut�t que de faire une boucle parcourant
%   chaque �l�ment du vecteur individuellement.
%
%   Dans ce contexte, il peut parfois �tre n�cessaire de seulement
%   effectuer des actions sur certaines parties du vecteur. La fonction
%   "find" pr�sent�e plus t�t devient particuli�rement ind�tressante.
%
%   Apprendre � vectoriser les processus matlab est une pratique tr�s
%   importante pour arriver � bien utiliser le logiciel.

x = rand(1,100);

x > 0.4 %Retourne un vecteur o� tous les indices de x dont la valeur est
        %sup�rieure � 0.4 sont mis � "1" et les autres � "0".
        
x < 0.6 %Retourne un vecteur o� tous les indices de x donc la valeur est
        % inf�rieure � 0.6 sont mis � "1" et les autres � "0".
        
indices = find(x> 0.4 &  x< 0.6)    %Retourne tous les indices dont la valeur
                                    %est entre 0.4 et 0.6.
                                    
% � la ligne pr�c�dente, ce qui arrive vraiment est :
% 1- x>0.4 retourne un vecteur avec des 1 et des 0 selon si la valeur est >
%    0.4
% 2- x<0.6 retourne un vecteur avec des 1 et des 0 selon si la valeur est <
%    0.6
% 3- le & combine les deux vecteurs
% 4 - Find retourne l'indice de tous les endroits � 1 (true)

%7.1 - �viter les boucles
%
%   Il est souvent possible d'optimiser le code en �liminant les boucles.
% 
%   Par exemple, le code :
%
%   count 0;
%   for n=1:length(x)
%       if x(n) > 0
%           count = count+1;
%       end
%   end
%
%   Peut �tre remplac� par le code :

count = length(find(x>0))

% Cette derni�re ligne s'ex�cutera environ 400 fois plus rapidement que la
% boucle "for" pr�c�dente.

            