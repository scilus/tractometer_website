function HelloWorldFunction()
%HELLOWORLDFUNCTION This function princes hello world.

disp('Hello World!');

end

