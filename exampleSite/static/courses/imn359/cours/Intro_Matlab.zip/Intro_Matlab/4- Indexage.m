% 4.0 - Indexage de vecteur
%
%   L'indexage en matlab est bas� � 1 plut�t qu'� 0, il faut donc faire
%   attention lorsqu'on acc�de � un �l�ment d'une matrice ou d'un vecteur.
%   Pour acc�der � un �l�ment pr�cis d'une matrice, on utilise l'op�rateur
%   () en y ins�rant l'index d�sir�.

a = [13 5 9 10]

a(1)
a(2)
a(3)
a(4)

% L'index peut aussi �tre un vecteur de plusieurs indexes, ce qui
% retournera plusieurs valeurs correspondants aux indexes contenus dans le
% vecteur.

a([1 2 1 3 4 4 4 1 2])

a(2:4) %On peut r�utiliser nos m�thodes d'initialisation de vecteur vue plus t�t!

% Un index sp�cial est aussi disponible, soit l'index "end" qui correspond
% au dernier index du vecteur.

a(2:end)

% Le tout fonctionne aussi identiquement si le vecteur est un vecteur
% colonne. Les valeurs seront dans ce cas-ci retourn�e en colonnes.

b = [10; 8; 5; 4]

b(3)

b(1:3)

% 4.1 - Indexage de matrice
%
%   L'indexage de matrice peut se faire avec un seul indice lin�aire ou 
%   une s�rie de sous-indices. Lorsqu'un indice lin�aire est utilis�, la
%   matrice est parcourue de haut en bas puis de gauche � droite. Lorsqu'une
%   s�rie de sous-indices est utilis�, le premier indice correspond � la
%   ligne et le second � la colonne.

a = [14 33; 9 8]

a(1)
a(1,1)

a(2)

a(3)
a(2,1)

a(4)

%   Comme plus t�t, il est possible de s�lectionner plusieurs �l�ments
%   d'une matrice en passant un vecteur.

a([1 2]) %Indices 1 et 2

a([1:3]) %Indices de 1 � 3

a([1 2],2) %Premi�re et deuxi�me ligne sur la deuxi�me colonne

% 4.2 - S�lection de ligne ou de colonne.
%
%   On peut vouloir aussi s�lectionner seulement une ligne ou une colonne
%   de la matrice. Dans ce cas, on utilise un intervale ouvert ":" qui
%   signifie "tous les indices possibles".

c = [12 5; -2 13]
d = c(1,:) % Toutes les valeurs de la ligne 1
e = c(:,2) % Toutes les valeurs de la colonne 2

c(2,:) = [3 6] %Remplacer les valeurs de la 2e ligne par [3 6]

% 4.3 - Indexage avanc�
%
%   Matlab contient des fonctions servant � retourner des indices en
%   particulier.

vec = [5 3 1 9 7]
[minVal,minIndex] = min(vec); %il existe aussi un "max".

%   On peut aussi utiliser la fonction "find" qui retourne tous les indices
%   correspondants � une condition bool�ene.

indexes = find(vec == 9)
indexes = find(vec >2 & vec < 6)

%   Il est possible d'utiliser find afin de g�n�rer des formulations
%   extr�mement performantes sous matlab.
%
%   Finalement, notons qu'il est possible de passer d'un indice � des
%   sous-indices ou vice-versa avec ind2sub et sub2ind

mat = [1 2; 3 4]
indexes = find(mat == 3)
[I,J] = ind2sub(size(mat),indexes)






