function M1sep = ifwtSep2D(MW, Jmin)

% Backward separable
M1sep = MW;
n = size(MW);
for i=1:n(1)
    M1sep(:,i) = perform_wavortho_transf(M1sep(:,i),Jmin,-1);
end
for i=1:n(2)
    M1sep(i,:) = perform_wavortho_transf(M1sep(i,:)',Jmin,-1)';
end

