
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Haar
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

h = [0 1/sqrt(2) 1/sqrt(2)];
g = [0 1/sqrt(2) -1/sqrt(2)];


%%%%%%%%%%%%%%%%%%%%%% Proof of concept of wavelets operations %%%%%%%%%%%%%
% This part just shows that wavelate operations are reversible
% fwd - low/high pass filtering + down sampling
% bwd - up sampling followed by low/high pass filtering with the reverse
% filters

n = 256;
f = rand(n,1);

a = subsampling( cconv(f,h) ); % subsamplling(A) is equivalent to A(1:2:end).
d = subsampling( cconv(f,g) );

f1 =  cconv(upsampling(a),reverse(h)) + ...
    cconv(upsampling(d),reverse(g));

disp(strcat((['Error |f-f1|/|f| = ' num2str(norm(f-f1)/norm(f))])));
plot(f,'r')
hold
plot(f1,'b')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

n = 512;
load piece_regular.mat
f = piece_regular;


fwt

clf;
plot_wavelet(fw);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% IFWT : Inverse Fast Wavelet Transform
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ifwt

disp(strcat((['Error |f-f1|/|f| = ' num2str(norm(f-f1)/norm(f))])));

subplot(2,1,1);
plot(f); axis('tight');
subplot(2,1,2);
plot(f1); axis('tight');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Visualiser les ondelettes
%
% Le coefficient d'ondelette fw[k] correspond au produit scalaire
% de f et psi_{j,n}, k depend de j et n
%
% Donc, l'ondelette f = psi_{j,n} est calcul� en utilisant la transform�e
% en ondelettes inverse au vecteur fw, ou fw[k] = 1 et fw[k] = 0 ailleurs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


shape;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% BAD WAVELET DESIGN FILTER
% 
% Gaussian filter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mu = 2;
% compute a Gaussian filter of width mu
t = (-n/2:n/2-1)';
h = exp( -(t.^2)/(2*mu^2) );

% g[n] = (-1)^(1-n) h[1-n];
g = [0 ; h(length(h):-1:2)]' .* (-1).^(1:length(h));


clf;
subplot(3,1,1);
plot(f); axis('tight'); title('Signal');
subplot(3,1,2);
plot(h); axis('tight'); title('Low-pass filter');
subplot(3,1,3);
plot(g); axis('tight'); title('High-pass filter');



a = subsampling( cconv( f, h) );
d = subsampling( cconv( f, g) );


clf;
subplot(3,1,1);
plot(f); axis('tight'); title('Signal');
subplot(3,1,2);
plot(1:2:n,a); axis('tight'); title('Low-pass filter');
subplot(3,1,3);
plot(1:2:n,d); axis('tight'); title('High-pass filter');

mu = 1;
% compute a Gaussian filter of width mu
t = (-n/2:n/2-1)';
h = exp( -(t.^2)/(2*mu^2) );

% g[n] = (-1)^(1-n) h[1-n];
g = [0 ; h(length(h):-1:2)]' .* (-1).^(1:length(h));


clf;
subplot(3,1,1);
plot(f); axis('tight'); title('Signal');
subplot(3,1,2);
plot(h); axis('tight'); title('Low-pass filter');
subplot(3,1,3);
plot(g); axis('tight'); title('High-pass filter');


a = subsampling( cconv( f, h) );
d = subsampling( cconv( f, g) );


clf;
subplot(3,1,1);
plot(f); axis('tight'); title('Signal');
subplot(3,1,2);
plot(1:2:n,a); axis('tight'); title('Low-pass filter');
subplot(3,1,3);
plot(1:2:n,d); axis('tight'); title('High-pass filter');


fwt
ifwt

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Conditions n�cessaires et suffisantes sur h et g non respect�es
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hf = fft(h);
gf = fft(g);


t = linspace(-pi(),pi(),n);
hold
plot(t,abs(hf), 'r');
plot(t,abs(gf), 'b');
abs(hf(n/2+1))
abs(fftshift(hf(n/2)))^2 + abs(fftshift(hf(n)))^2





%%% HAAR
h = zeros(1,n);
g = zeros(1,n);

h(n/2-1) = 1/sqrt(2); h(n/2) = 1/sqrt(2);
g(n/2-1) = 1/sqrt(2); g(n/2) = -1/sqrt(2);
t = linspace(-pi(),pi(),n);
hf = fft(h);
gf = fft(g);

plot(t,abs(fftshift(hf)), 'r');
abs(hf(n/2+1))
abs(fftshift(hf(n/2)))^2 + abs(fftshift(gf(n)))^2

%%% Daubechies
[h g] = compute_wavelet_filter('Daubechies', 4)
shape

%%% Jouez avec compute_wavelet_filter





