%fwtSep2D
function MWsep = fwtSep2D(M)

MWsep = M;
Jmin = 1;
n = size(M);
for i=1:n(1)
    MWsep(:,i) = perform_wavortho_transf(MWsep(:,i),Jmin,+1);
end
for i=1:n(2)
    MWsep(i,:) = perform_wavortho_transf(MWsep(i,:)',Jmin,+1)';
end
