% Demo texture
%
% On se donne un spectre de Fourier 2D vide
kx = 5;
ky = 8;
N = 129    % j'aime les nombres impaires car le centre de l'image est plus simple a trouver
           % le centre sera a (65, 65)

I = zeros(N)
centrex = (N+1)/2;
centrey = (N+1)/2;

I(centrex, centrey) = 1; % verifier que c'est bien le centre de l'image
imagesc(I)

% on remet un 0
I(centrex,centrey)=0;

% on commence par une texture en rangee, frequence kx
I(centrex - kx, centrey) = N*(N/2); % il faut refaire les maths pour avoir la preuve que c'est bien N^2/2 ici
I(centrex + kx, centrey) = N*(N/2);
imagesc(I)

Ishift = ifftshift(I);
imagesc(Ishift)

% TFD inverse 2D. A noter que le resultat n'a PAS de complexe qui traine
texture = ifft2(Ishift);
figX = figure
colormap 'gray'
imagesc(texture)

% Texture sur les colonnes maintenant.
I = zeros(N);
I(centrex, centrey+ky) = N*(N/2); 
I(centrex, centrey-ky) = N*(N/2);
imagesc(I)

Ishift = ifftshift(I);
imagesc(Ishift)
texture = ifft2(Ishift);
figY = figure
colormap 'gray'
imagesc(texture)


% Texture diagonale
I = zeros(N)
I(centrex+kx, centrey+ky) = N*(N/2); 
I(centrex-kx, centrey-ky) = N*(N/2);
imagesc(I)

Ishift = ifftshift(I);
imagesc(Ishift)
texture = ifft2(Ishift);
figD = figure
colormap 'gray'
imagesc(texture)