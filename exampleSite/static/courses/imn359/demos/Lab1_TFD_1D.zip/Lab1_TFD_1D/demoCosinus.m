% un cos qui oscille N fois par p�riode
k0 = 4; 
N = 1001;
n = 1:N
y = cos(2*pi/N*k0*n);
plot(n, y, '.', 'linewidth', 2);

Y = fft(y)
plot(abs(Y), 'o-', 'linewidth', 2);

plot(fftshift(abs(Y)), 'o-', 'linewidth', 2);

%demoCosinus 1D
N = 128;
F = zeros(N,1);
plot(F, '.--', 'linewidth', 2);


% si on veut que Cosinus oscille k fois sur l'interval 128
% La preuve est dans les diapositives
k = 5;
F(k+1) = N/2;
F(N+1- k) = N/2;
plot(F, '.--')
plot(ifft(F), 'linewidth', 2);



x = 1:128;
f = cos( 2* pi / N * k * x);

figure
plot(f, 'g', 'linewidth', 2);


figure
plot(abs(fft(f)), 'go', 'linewidth', 2);


figure
subplot(1,2,1);
plot(F);
subplot(1,2,2);
plot(abs(fft(f)), 'r', 'linewidth', 2);



figure
subplot(1,2,1);
plot(ifft(F));
subplot(1,2,2);
plot(ifft((fft(f))), 'r', 'linewidth', 2);
axis([ 0 128 -1 1]);


figure
subplot(1,2,1);
plot(F, 'b.--', 'linewidth', 2);
subplot(1,2,2);
plot(fftshift(F), 'g.--', 'linewidth', 2);




