load piece-regular.mat
n = length(x0);
x = x0;

% Local DCT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Approximation avec des cosinus locaux
%
% Ameliore l'approximation globale de la DCT
% On decoupe le signal en segments locaux (patches en 2D) dans lesquels on
% fait la DCT
%
% JPEG est bas� sur cette base
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
w = 16; % taille du segment


fc = dct( x );
fc_a = zeros(size(x));

% DCT local
for i=1:n/w
  seli = (i-1)*w+1:i*w;

  fc_a(seli) = dct( x(seli) );
end


hold
plot(1:n, abs(fc), 'b');
plot(1:n, abs(fc_a), 'r');


% Lets keep 4 lowest frequency coefficients in each bin (4* n/w in total)
% iDCT local
f1 = idct( fc );
fm_local = fc_a;
fc_a_4 = zeros(n,1);
fm_a = zeros(n,1);
for i=1:n/w
  seli = (i-1)*w+1:i*w;

  sel_a = (i-1)*w+1:(i-1)*w+4;

  fc_a_4(sel_a) = fm_local(sel_a);

  fm_local(seli) = idct( fm_local(seli) );

  fm_a(seli) = idct( fc_a_4(seli) );

end
f = x;


fc_2 = zeros(n,1);
fc_2(1:256) = fc(1:256);
f1_2 = idct( fc_2 );

ff = fft(x0);
ffamp = abs( fftshift( ff ) );
ffs = fftshift( ff );
%plot(ffamp);
ffs_2 = zeros(n,1);
ffs_2(n/2-128:n/2+127) = ffs(n/2-128:n/2+127);

xx = abs( ifft( fftshift( ffs_2 ) ));

disp(strcat((['Error |f-f1|/|f| using a full Discrete Cosine basis = ' num2str(norm(f-f1)/norm(f))])));
disp(strcat((['Error |f-f1|/|f| using a full local Discrete Cosine basis = ' num2str(norm(f-fm_local)/norm(f))])));
disp(strcat((['Error |f-fm|/|f| using a linear (256 coeffs) local Discrete Cosine approximation = ' num2str(norm(f-fm_a)/norm(f))])));
disp(strcat((['Error |f-fm|/|f| using a linear (256 coeffs) Discrete Cosine approximation = ' num2str(norm(f-f1_2)/norm(f))])));
disp(strcat((['Error |f-fm|/|f| using a linear (256 coeffs) Fourier approximation = ' num2str(norm(f-xx)/norm(f))])));



subplot(5,1,1);
plot(f);  axis 'tight'; title(strcat((['Full DCT, error = ' num2str(norm(f-f1)/norm(f))])))
subplot(5,1,2);
plot(f1); axis 'tight'; title(strcat((['Full locDCT, error = ' num2str(norm(f-fm_local)/norm(f))])))
subplot(5,1,5);
plot(fm_a');   axis 'tight'; title(strcat((['256 coeffs of localDCT (4 per bin), error = ' num2str(norm(f-fm_a)/norm(f))])))
subplot(5,1,4);
plot(f1_2');   axis 'tight'; title(strcat((['256 coeffs of DCT, error = ' num2str(norm(f-f1_2)/norm(f))])))
subplot(5,1,3);
plot(xx);   axis 'tight'; title(strcat((['256 coeffs of FFT, error = ' num2str(norm(f-xx)/norm(f))])))
