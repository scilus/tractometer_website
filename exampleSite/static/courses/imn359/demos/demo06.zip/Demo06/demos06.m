%%% demos06
load mandrill.mat

% Compute and display the Fourier transform (display over a log scale). The function fftshift is useful to put the 0 low frequency in the middle. After fftshift, the zero frequency is located at position (n/2+1,n/2+1). 
Mf = fft2(M);
Lf = fftshift(log( abs(Mf) ));
fig1 = figure
subplot(1,2,1); imagesc(M); colormap(gray);  axis image; axis off; 
subplot(1,2,2); imagesc(Lf); colormap(gray);  axis image; axis off; 


n = 512; % size of mandril
m = n/2; % 2 coefficients in X and Y
F1 = zeros(n,n);

F = fftshift(fft2(M));
F1 = zeros(n);
sel = (n/2-m/2:n/2+m/2)+1;
F1(sel,sel) = F(sel,sel); 

fig2 = figure
subplot(1,2,1); imagesc(log(abs(F1))); colormap(gray);  axis image; axis off; title(['Cropped spectrum : ' num2str(m*m/(n*n)*100) '% of coefficients']);
subplot(1,2,2); imagesc(Lf); colormap(gray);  axis image; axis off; title('Original spectrum');



M1 = real( ifft2(fftshift(F1)) );


% display
fig3 = figure;
subplot(1,2,1); imagesc(M); colormap(gray);  axis image; axis off; title('Original image');
subplot(1,2,2); imagesc(M1); colormap(gray);  axis image; axis off; title(['Approx, SNR=' num2str(snr(M,M1), 4) 'dB']);




% Less coefficients
m = n/16; % 4 coefficients in X and Y
F1 = zeros(n,n);

F = fftshift(fft2(M));
F1 = zeros(n);
sel = (n/2-m/2:n/2+m/2)+1;
F1(sel,sel) = F(sel,sel); 

fig4 = figure;
subplot(1,2,1); imagesc(log(abs(F1))); colormap(gray);  axis image; axis off; title(['Cropped spectrum : ' num2str(m*m/(n*n)*100) '% of coefficients']);
subplot(1,2,2); imagesc(Lf); colormap(gray);  axis image; axis off; title('Original spectrum');


M1 = real( ifft2(fftshift(F1)) );


% display
clf;
subplot(1,2,1); imagesc(M); colormap(gray);  axis image; axis off; title('Original image');
subplot(1,2,2); imagesc(M1); colormap(gray);  axis image; axis off; title(['Approx, SNR=' num2str(snr(M,M1), 4) 'dB']);



%%%%% Try with cameraman %%%%%

load cameraman.mat
n = 512;
M = cameraman;
m = n/16; % 2 coefficients in X and Y
F1 = zeros(n,n);

Mf = fft2(M);
Lf = fftshift(log( abs(Mf) ));
F = fftshift(fft2(M));
F1 = zeros(n);
sel = (n/2-m/2:n/2+m/2)+1;
F1(sel,sel) = F(sel,sel); 

fig5 = figure;
subplot(1,2,1); imagesc(log(abs(F1))); colormap(gray);  axis image; axis off; title(['Cropped spectrum : ' num2str(m*m/(n*n)*100) '% of coefficients']);
subplot(1,2,2); imagesc(Lf); colormap(gray);  axis image; axis off; title('Original spectrum');


M1 = real( ifft2(fftshift(F1)) );


% display
fig6 = figure;
subplot(1,2,1); imagesc(M); colormap(gray);  axis image; axis off; title('Original image');
subplot(1,2,2); imagesc(M1); colormap(gray);  axis image; axis off; title(['Approx, SNR=' num2str(snr(M,M1), 4) 'dB']);



% add noise
sigma = .1;
Mn = M + randn(size(M))*sigma;
imagesc( Mn ); colormap(gray);

Mnf = fft2( Mn );
Mnf_shift = fftshift( Mnf );
Lnf = fftshift ( log( abs( Mnf ) ) );
imagesc( Lnf );

m = n/2;
F1 = zeros(n);
sel = (n/2-m/2:n/2+m/2)+1;
F1(sel,sel) = Mnf_shift(sel,sel); 

fig7 = figure;
subplot(1,3,1); imagesc(real( ifft2( fftshift( F1 ) ) )); colormap(gray); axis image; axis off; title(['Cropped Fourier : ' num2str(m*m/(n*n)*100) '% of coefficients']);
subplot(1,3,2); imagesc( real( ifft2( Mnf )) ); colormap(gray);  axis image; axis off; title('Full Fourier noisy');
subplot(1,3,3); imagesc( M ); colormap(gray);  axis image; axis off; title('Original');


