import cmath as cm
import matplotlib.pyplot as plt
import numpy as np
from scipy.io import loadmat
from scipy.signal import convolve2d
from scipy.fft import fft2, fftshift, ifftshift, ifft2

I = loadmat("lena.mat")['lena']

# moyenne
h = [[1/3, 1/3, 1/3]]
Moy1 = convolve2d(I, h)

h = [[1/5, 1/5, 1/5, 1/5, 1/5]]
Moy2 = convolve2d(I, h)

fig, axs = plt.subplots(1,3)
axs[0].imshow(I)
axs[1].imshow(Moy1)
axs[2].imshow(Moy2)
plt.show()

# Derive
h = [[-1/2, 0, 1/2]]
I_x = convolve2d(I, np.array(h).T)

plt.imshow(I_x)
plt.show()

I_y = convolve2d(I, h)
plt.clf()
plt.imshow(I_y)
plt.show()

# Accelerer la convolution
# C = convolve2d(I, I, mode='same')

# Beaucoup plus rapide d'utiliser le thm de convolution
CC = fftshift(ifft2(fft2(I) * fft2(I)))

# Convolution
h = np.zeros((512, 512))
h[246: 267, 246: 267] = np.ones((21, 21))

plt.clf()
plt.imshow(h)
plt.show()

filtre = h

# C = convolve2d(I, filtre, mode='same')

# Beaucoup plus rapide d'utiliser le thm de convolution
CC = np.real(fftshift(ifft2(fft2(I) * fft2(filtre))))

plt.clf()
plt.imshow(CC)
plt.show()

# Plancherel
# Energy dans Lena
energy = np.sum(np.abs(pow(I, 2)))
print(energy)

IF = fft2(I)

energy2 = np.sum(np.abs(pow(IF, 2)))
print(energy2)

test = energy2 / pow(len(I), 2)
print(test)
