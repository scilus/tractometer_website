import cmath as cm
import matplotlib.pyplot as plt
import numpy as np
from scipy.io import loadmat

from scipy.fft import fft, fftshift, ifftshift, ifft

from delta import delta

M = loadmat("piece-regular.mat")['x0']

plt.plot(range(0, 1024), M, '--.', linewidth=2)
plt.show()

plt.clf()
plt.plot(range(-512, 512), fftshift(np.abs(fft(M))), '--.r', linewidth=2)
plt.show()

# Exemple d'echantillonnage
f0 = 0.5
t = np.arange(-2 * np.pi, 2 * np.pi, 0.01)
y = 2 * np.sin(2 * np.pi * f0 * t)

plt.clf()
plt.plot(t, y, linewidth=2)
plt.show()

ts = 20
ii = np.arange(1, len(t), ts)
t0 = t[ii]
d = delta(t, t0)

plt.clf()
plt.plot(t, y, 'b-', t, d, 'ro-', linewidth=2)
plt.show()

ys = y * d
t2 = t[ys != 0]
ys = ys[ys != 0]

plt.clf()
plt.plot(t2, ys, 'bo-', linewidth=2)
plt.show()

# Exemple de repliement
lim = 16
t1 = np.arange(0, 1, 1/1000) # ts = 0.001 second, fs = 1000
t2 = np.arange(0, 1, 1/100) # ts = 0.01 second, fs = 100
t3 = np.arange(0, 1, 1/50) # ts = 0.05 second, fs = 20
t4 = np.arange(0, 1, 1/10) # ts = 0.1 second, fs = 10
t5 = np.arange(0, 1, 1/lim)

f1 = 8
T1 = 1/f1 # frequence de 8Hz
f2 = 3
T2 = 1/f2 # frequence de 3 Hz

# Frequence fondamentale
s1 = np.cos(2 * np.pi * f1 * t1) + np.cos(2 * np.pi * f2 * t1)
s2 = np.cos(2 * np.pi * f1 * t2) + np.cos(2 * np.pi * f2 * t2)
s3 = np.cos(2 * np.pi * f1 * t3) + np.cos(2 * np.pi * f2 * t3)
s4 = np.cos(2 * np.pi * f1 * t4) + np.cos(2 * np.pi * f2 * t4)
s5 = np.cos(2 * np.pi * f1 * t5) + np.cos(2 * np.pi * f2 * t5)

fig, axs = plt.subplots(4,1)
axs[0].plot(t1, s1, '-b')
axs[1].plot(t2, s2, '-bo')
axs[2].plot(t3, s3, '-bo')
axs[3].plot(t4, s4, '-bo')
plt.show()

f1 = range(-500, 500)
f2 = range(-50, 50)
f3 = range(-25, 25)
f4 = range(-5, 5)
f5 = range(int(-lim/2), int(lim/2))

fig, axs = plt.subplots(4,1)
axs[0].plot(f1, np.abs(fftshift(fft(s1))), 'o', linewidth=2)
axs[1].plot(f2, np.abs(fftshift(fft(s2))), 'o', linewidth=2)
axs[2].plot(f3, np.abs(fftshift(fft(s3))), 'o', linewidth=2)
axs[3].plot(f4, np.abs(fftshift(fft(s4))), 'o', linewidth=2)
plt.show()

plt.clf()
plt.plot(f5, np.abs(fftshift(fft(s5))), 'o', linewidth=2)
plt.show()

# Exemple de recouvrement
t = np.arange(-1, 1.1, 0.1) #Echantillonne a 10 Hz
a = [0.5, 4]
y = a[0] * np.exp(-a[1] * a[1] * pow(t, 2))
fs = np.arange(-5, 5.5, 0.5)

plt.clf()
plt.plot(t, y, '-bo')
plt.plot(fs, np.abs(fftshift(fft(y))), '-ro')
plt.show()

t = np.arange(-1, 1.3, 0.3) # Echantillone a 10/3 Hz
a = [0.5, 4]
y = a[0] * np.exp(-a[1] * a[1] * pow(t, 2))

fs = np.arange(-5, 4.9, 10/len(t))

plt.clf()
plt.plot(t, y, '-bo')
plt.plot(fs, np.abs(fftshift(fft(y))), '-ro')
plt.show()

# Echantillonnage
M = loadmat("piece-regular.mat")['x0']

# C'est comme si on avait echantillonne le signal a tous les 1/1024 pts
# ou 1024 Hz
t = np.linspace(0, 1, 1024)

plt.clf()
plt.plot(t, M)
plt.show()

f = np.linspace(-512, 512, 1024)

plt.clf()
plt.plot(f, np.abs(fft(M)))
plt.show()

# On voit que la fft est symetrique. En fait, on a que de l'information sur
# 1024/2 frequences a cause des coefficients complexe de la TF
plt.clf()
plt.plot(f, np.abs(fftshift(fft(M))))
plt.show()

# Qu'est-ce que ca veut dire? Ca veut dire que si nous voulons les
# frequences 'f', il faut au moins echantillonner a 2*f (1/(2*f)) dans le
# monde spatial
f2 = M[1:8:]
t2 = t[1:8:]

plt.clf()
plt.plot(t2, f2)
plt.show()

f = np.linspace(-np.shape(f2)[0] / 2, np.shape(f2)[0] / 2, np.shape(f2)[0])

plt.clf()
plt.plot(f, np.abs(fftshift(fft(f2))))
plt.show()
