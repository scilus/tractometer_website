E = [1 1 1 1; 1 -i -1 i; 1 -1 1 -1; 1 i -1 -i]
g = [0 1 2 3]

%TDF
G = g*E

%iTDF

g3 = G*conj(E)

g4 = fft(g)


% introduction � Fourier
load piece-regular
g = x0;
G = fft(g);
t = linspace(0,1,size(g,1));
f = linspace(-512, 512, 1024);
plot(t, g)
plot(f, real(fftshift(G)))
plot(f, imag(fftshift(G)))
plot(f, abs(fftshift(G)))



load bird
t = linspace(0,1,size(x,1));
plot(t, x)
f = linspace(-size(x,1)/2, size(x,1)/2, size(x,1));
plot(f, abs(fftshift(fft(x))))

