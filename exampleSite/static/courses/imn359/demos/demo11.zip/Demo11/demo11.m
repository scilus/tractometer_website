%%% demo des ondelettes de Haar 1D

%%%%%%%%%%%%%%%% 1D Haar Wavelet DECOMPOSITION %%%%%%%%%%%%%%%%%%%%%%
% get signal
load piece_regular.mat
n = 512;
f = piece_regular;
plot(f);


% initialize coeffs as signal itself, 
% scale 2^9 = 512 bins, resolution 2^{-9}
fw = f;

% initial scale j is the max one
j = log2(n)-1;

% fw coefficients will be iteratively computed until they contain the Haar
% wavelet

A = fw(1:2^(j+1));

% 256x1
% we compute average and differences to get coarse and details. 
% They are weighted by 1/sqrt(2) to maintain orthogonality.
Coarse = ( A(1:2:length(A)) + A(2:2:length(A)) )/2;
Detail = ( A(1:2:length(A)) - A(2:2:length(A)) )/2;


% Concatinate
A = [Coarse; Detail];

% plot Coarse
clf;
subplot(2,1,1);
plot(1:n,f,'.-'); axis('tight'); title('Signal');
subplot(2,1,2);
plot(1:2:n,Coarse,'.-'); axis('tight'); title('Coarse');



% on zoom dans une region de Coarse
s = 400; t = 40;
clf;
subplot(2,1,1);
plot(f,'o-'); axis([s-t s+t 0 1]); title('Signal (zoom)');
subplot(2,1,2);
plot(Coarse,'o-'); axis([(s-t)/2 (s+t)/2 min(A) max(A)]); title('Averages (zoom)');


% plot Details
clf;
subplot(2,1,1);
plot(1:n,f,'.-'); axis('tight'); title('Signal');
subplot(2,1,2);
plot(1:2:n,Detail,'.-'); axis('tight'); title('Details');


% plot Both
clf;
subplot(2,1,1);
plot(f); axis('tight'); title('Signal');
subplot(2,1,2);
plot(A); axis('tight'); title('Transformed');

clf;
subplot(2,1,1);
plot(A(1:256)); axis('tight'); title('Signal');
subplot(2,1,2);
plot(A(257:end)); axis('tight'); title('Transformed');



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
computeHaar1D
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp(strcat(['Energy of the signal       = ' num2str(norm(f).^2,3)]));
disp(strcat(['Energy of the coefficients = ' num2str(norm(fw).^2,3)]));



% Plot the coefficients
clf;
plot_wavelet(fw);
axis([1 n -2 2]);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1D Reconstruction 
%
% Initialize the image to recover f1 as the transformed coefficient, 
% and select the smallest possible scale.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

f1 = fw;
j = 0;

%Retrieve coarse and detail coefficients in the vertical direction.
Coarse = f1(1:2^j);
Detail = f1(2^j+1:2^(j+1));

%Undo the transform by computing sums and differences.

f1(1:2:2^(j+1)) = ( Coarse + Detail )/sqrt(2);
f1(2:2:2^(j+1)) = ( Coarse - Detail )/sqrt(2);


computeHaar1DReconstruction

% Original image versus Reconstructed image
disp(strcat((['Error |f-f1|/|f| = ' num2str(norm(f-f1)/norm(f))])));

subplot(2,1,1);
plot(f); axis('tight'); title('Original signal');
subplot(2,1,2);
plot(f1); axis('tight'); title(['Reconstructed signal with full HAAR transform, error = ' num2str(norm(f-f1)/norm(f))]);


%%%%%%%%%%%%%%%%%%
% Approximations %
%%%%%%%%%%%%%%%%%%
cut = 100;
fw_a = zeros(length(fw), 1); fw_a(1:cut) = fw(1:cut);
plot_wavelet(fw_a);

fw_max = perform_largest_thresh(fw, cut);
plot_wavelet(fw_max)


clf;
subplot(2,1,1);
plot_wavelet(fw_a); title('Linear approximation');
subplot(2,1,2);
plot_wavelet(fw_max); title('Nonlinear approximation');


fw = fw_a;
computeHaar1DReconstruction;
f1_a = f1;

fw = fw_max;
computeHaar1DReconstruction;
f1_max = f1;

clf;
subplot(3,1,1);
plot(f,'-','LineWidth',2); axis('tight'); title('Original Signal');
subplot(3,1,2);
plot(f1_a,'r-','LineWidth',2); axis('tight'); title(['Linear approximation with ' num2str(cut) ' coefficients']);
disp(strcat((['Error |f-f1_a|/|f| = ' num2str(norm(f-f1_a)/norm(f))])));
subplot(3,1,3);
plot(f1_max,'g-','LineWidth',2); axis('tight'); title(['Nonlinear approximation with ' num2str(cut) ' coefficients']);
disp(strcat((['Error |f-f1_max|/|f| = ' num2str(norm(f-f1_max)/norm(f))])));


