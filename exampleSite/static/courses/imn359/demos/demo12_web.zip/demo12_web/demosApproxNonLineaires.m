%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% APPROXIMATIONS NONLIN�AIRES DANS DES BASES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load piece_regular.mat;
f = piece_regular;
n = 512;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Approximation dans Fourier
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ft = fftshift(fft(f));
ft_a = zeros(n,1);

m = 128;
sel = (n/2-m/2+1:n/2+m/2);
size(sel);

ft_a(sel) = ft(sel);    % Approximation lineaire gardant que les 128 premiers coeffs
ft_n = perform_largest_thresh(ft, m);  % Approximation nonlineaire

hold on;
figure(1)
plot(1:n, abs(ft), 'b');
plot(1:n, abs(ft_a), 'r');
plot(1:n, abs(ft_n), 'g');
hold off;

ft_n = perform_largest_thresh(ft, m);


f1 = ifft(fftshift(ft));
disp(strcat((['Error |f-f1|/|f| using full Fourier basis = ' num2str(norm(f-f1)/norm(f))])));

fm = real(ifft(fftshift(ft_a)));
fn = real(ifft(fftshift(ft_n)));
disp(strcat((['Linear Error |f-fm|/|f| using Fourier basis = ' num2str(norm(f-fm)/norm(f))])));
disp(strcat((['Nonlinear Error |f-fn|/|f| using Fourier basis = ' num2str(norm(f-fn)/norm(f))])));

figure(2)
subplot(4,1,1);
plot(f); title('Original signal'); axis 'tight'; 
subplot(4,1,2);
plot(f1); title((['Signal from full Fourier spectrum reconstruction, Error = ' num2str(norm(f-f1)/norm(f))])); axis 'tight'; 
subplot(4,1,3);
plot(fm);  title((['Linear approximation with m = 128 coefficients, Error = ' num2str(norm(f-fm)/norm(f))])); axis 'tight'; 
subplot(4,1,4);
plot(fn);  title((['Nonlinear approximation with m = 128 coefficients, Error = ' num2str(norm(f-fn)/norm(f))])); axis 'tight'; 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Erreurs d'approximation calculees sur les coeffs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
linear_error = ft - ft_a;
disp(strcat((['Linear error = ' num2str(norm(linear_error)/norm(ft))])));
nonlinear_error = ft - ft_n;
disp(strcat((['Nonlinear error = ' num2str(norm(nonlinear_error)/norm(ft))])));



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Approximation avec des cosinus discrets
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fc = dct(f);
fc_a = zeros(n,1);

m = 128;
sel = 1:m;
size(sel);

fc_a(sel) = fc(sel);    % Approximation lin�aire gardant que les 128 premiers coeffs
fc_n = perform_largest_thresh(fc, m);


hold on;
figure(3)
plot(1:n, fc, 'b');
plot(1:n, fc_a, 'r');
plot(1:n, fc_n, 'g');
hold off;

f1 = idct(fc);
disp(strcat((['Error |f-f1|/|f| using a full Discrete Cosine basis = ' num2str(norm(f-f1)/norm(f))])));

fm = idct(fc_a);
disp(strcat((['Error |f-fm|/|f| using a linear Discrete Cosine (DC) approximation = ' num2str(norm(f-fm)/norm(f))])));
fn - idct(fc_n);
disp(strcat((['Linear Error |f-fm|/|f| using DC basis = ' num2str(norm(f-fm)/norm(f))])));
disp(strcat((['Nonlinear Error |f-fn|/|f| using DC basis = ' num2str(norm(f-fn)/norm(f))])));


figure(4)
subplot(4,1,1);
plot(f); title('Original signal'); axis 'tight'; 
subplot(4,1,2);
plot(f1); title((['Signal from full DCT reconstruction, Error = ' num2str(norm(f-f1)/norm(f))])); axis 'tight'; 
subplot(4,1,3);
plot(fm);  title((['Linear approximation with m = 128 coefficients, Error = ' num2str(norm(f-fm)/norm(f))])); axis 'tight'; 
subplot(4,1,4);
plot(fn);  title((['Nonlinear approximation with m = 128 coefficients, Error = ' num2str(norm(f-fn)/norm(f))])); axis 'tight'; 

% Erreurs d'approximation calculees sur les coeffs
linear_error = fc - fc_a;
disp(strcat((['Linear error = ' num2str(norm(linear_error)/norm(fc))])));
nonlinear_error = fc - fc_n;
disp(strcat((['Nonlinear error = ' num2str(norm(nonlinear_error)/norm(fc))])));



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Approximation avec des cosinus locaux
% 
% Ameliore l'approximation globale de la DCT
% On decoupe le signal en segments locaux (patches en 2D) dans lesquels on
% fait la DCT
%
% JPEG est bas� sur cette base
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
w = 16; % taille du segment

fc_a = zeros(n,1);

% DCT local 
for i=1:n/w
  seli = (i-1)*w+1:i*w;
  
  fc_a(seli) = dct( f(seli) );
end


fc_n = perform_largest_thresh(fc_a, m);

hold on;
figure(5)
plot(1:n, fc, 'b');   % dct coeffs
plot(1:n, fc_a, 'r'); % localDCT coeffs 
plot(1:n, fc_n, 'g'); % largest m locDCT coeffs
hold off;

% We have bins of 16 units, so 32 bins over the signal f with n = 512. This
% means that we want to keep 128 coefficients, we keep 4 lowest frequency
% coefficients in each bin

% iDCT local
fm_local = fc_a;
fn_local = fc_n;
fc_a_4 = zeros(n,1);
fm_a = zeros(n,1);
for i=1:n/w
  seli = (i-1)*w+1:i*w; 
  
  sel_a = (i-1)*w+1:(i-1)*w+4;
  
  fc_a_4(sel_a) = fm_local(sel_a);
  
  fm_local(seli) = idct( fm_local(seli) );
  
  fn_local(seli) = idct( fn_local(seli) );
  
  fm_a(seli) = idct( fc_a_4(seli) );
  
end

disp(strcat((['Error |f-f1|/|f| using a full Discrete Cosine basis = ' num2str(norm(f-f1)/norm(f))])));
disp(strcat((['Error |f-f1|/|f| using a full local Discrete Cosine basis = ' num2str(norm(f-fm_local)/norm(f))])));
disp(strcat((['Linear Error |f-fm|/|f| using local DCT M-approximation = ' num2str(norm(f-fm_a)/norm(f))])));
disp(strcat((['Nonlinear Error |f-fm|/|f| using local DCT M-approximation = ' num2str(norm(f-fn_local)/norm(f))])));

figure(6)
subplot(4,1,1);
plot(f); title('Original signal'); axis 'tight'; 
subplot(4,1,2);
plot(fm_local); title((['Signal from full localDCT reconstruction, Error = ' num2str(norm(f-fm_local)/norm(f))])); axis 'tight'; 
subplot(4,1,3);
plot(fm_a);  title((['Linear approximation with m = 128 coefficients, Error = ' num2str(norm(f-fm_a)/norm(f))])); axis 'tight'; 
subplot(4,1,4);
plot(fn_local);  title((['Nonlinear approximation with m = 128 coefficients, Error = ' num2str(norm(f-fn_local)/norm(f))])); axis 'tight'; 

% Erreurs d'approximation calculees sur les coeffs
linear_error = fm_local - fm_a;
disp(strcat((['Linear error = ' num2str(norm(linear_error)/norm(fm_local))])));
nonlinear_error = fm_local - fn_local;
disp(strcat((['Nonlinear error = ' num2str(norm(nonlinear_error)/norm(fm_local))])));






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Approximation avec des ondelettes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Haar 
h = [0 1/sqrt(2) 1/sqrt(2)];
g = [0 1/sqrt(2) -1/sqrt(2)];

fwt1;

ifwt1;
disp(strcat((['Error |f-f1|/|f| using a full Haar wavelet basis = ' num2str(norm(f-f1)/norm(f))])));

fw_a = zeros(n,1);

m = 128;
sel = 1:m;
size(sel);

fw_a(sel) = fw(sel);

fw_n = perform_largest_thresh(fw, m);


hold on;
figure(7)
plot(1:n, fw, 'b');   
plot(1:n, fw_a, 'r');
plot(1:n, fw_n, 'g'); 
hold off;

figure(8)
subplot(4,1,1);
plot(f); title('Original signal'); axis 'tight'; %axis([1:n 0 1]);
subplot(4,1,2);
plot(f1); title('Signal from full Haar wavelet '); axis 'tight'; %axis([1:n 0 1]);

fw = fw_a;
ifwt1;
disp(strcat((['Error |f-fm|/|f| using a linear Haar wavelet approximation = ' num2str(norm(f-f1)/norm(f))])));
subplot(4,1,3);
plot(f1);  title((['Linear approximated signal with m = 128 Haar wavelet coefficients, error = = ' num2str(norm(f-f1)/norm(f))])); axis 'tight';

fw = fw_n;
ifwt1;
disp(strcat((['Error |f-fn|/|f| using a nonlinear Haar wavelet approximation = ' num2str(norm(f-f1)/norm(f))])));
subplot(4,1,4);
plot(f1);  title((['Nonlinear approximated signal with m = 128 Haar wavelet coefficients, error = = ' num2str(norm(f-f1)/norm(f))])); axis 'tight'; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% D4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[h, g] = compute_wavelet_filter('Daubechies', 4);

fwt1;
ifwt1;
disp(strcat((['Error |f-f1|/|f| using a full D4 wavelet basis = ' num2str(norm(f-f1)/norm(f))])));

fw_a = zeros(n,1);

m = 128;
sel = 1:m;
size(sel);

fw_a(sel) = fw(sel);
fw_n = perform_largest_thresh(fw, m);

hold on;
figure(10)
plot(1:n, fw, 'b');   
plot(1:n, fw_a, 'r');
plot(1:n, fw_n, 'g'); 
hold off;

figure(11)
subplot(4,1,1);
plot(f); title('Original signal'); axis 'tight'; %axis([1:n 0 1]);
subplot(4,1,2);
plot(f1); title('Signal from full Haar wavelet '); axis 'tight'; %axis([1:n 0 1]);

fw = fw_a;
ifwt1;
disp(strcat((['Error |f-fm|/|f| using a linear D4 wavelet approximation = ' num2str(norm(f-f1)/norm(f))])));
subplot(4,1,3);
plot(f1);  title((['Linear approximated signal with m = 128 D4 wavelet coefficients, error = = ' num2str(norm(f-f1)/norm(f))])); axis 'tight';

fw = fw_n;
ifwt1;
disp(strcat((['Error |f-fn|/|f| using a nonlinear D4 wavelet approximation = ' num2str(norm(f-f1)/norm(f))])));
subplot(4,1,4);
plot(f1);  title((['Nonlinear approximated signal with m = 128 Haar wavelet coefficients, error = = ' num2str(norm(f-f1)/norm(f))])); axis 'tight'; 

% Erreur d'approximation 11 fois meilleure qu'avec Haar


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Approximation avec des ondelettes biorthogonales
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
options.null = 0;
separable = getoptions(options, 'separable', 0);
options.separable = separable;
% 7/9 wavelets, p = 4 vanishing moments
options.h = getoptions(options, 'filter', '7-9');


fw = perform_wavelet_transf(f, 1, +1, options);
fw_n = perform_largest_thresh(fw, m);


f1 = perform_wavelet_transf(fw, 1, -1, options);
disp(strcat((['Error |f-f1|/|f| using a full 7/9 lifting wavelet basis = ' num2str(norm(f-f1)/norm(f))])));

figure(12)
subplot(4,1,1);
plot(f); title('Original signal'); axis 'tight'; %axis([1:n 0 1]);
subplot(4,1,2);
plot(f1); title('Signal from full 7/9 lifting wavelets '); axis 'tight'; %axis([1:n 0 1]);

fw_a = zeros(n,1);
m = 128;
sel = 1:m;
size(sel);
fw_a(sel) = fw(sel);

f1 = perform_wavelet_transf(fw_a, 1, -1, options);
disp(strcat((['Error |f-fm|/|f| using a linear 7/9 lifting wavelet approximation = ' num2str(norm(f-f1)/norm(f))])));
subplot(4,1,3);
plot(f1);  title('Approximated signal with m = 128, 7/9 lifting wavelet coefficients'); axis 'tight'; %axis([1:n 0 1]);

f1 = perform_wavelet_transf(fw_n, 1, -1, options);
disp(strcat((['Error |f-fn|/|f| using a nonlinear 7/9 lifting wavelet approximation = ' num2str(norm(f-f1)/norm(f))])));
subplot(4,1,4);
plot(f1);  title('Nonlinear approximated signal with m = 128, 7/9 lifting wavelet coefficients'); axis 'tight'; %axis([1:n 0 1]);

% Erreur d'approximation 23 fois meilleure qu'avec l'approximation lineaire













