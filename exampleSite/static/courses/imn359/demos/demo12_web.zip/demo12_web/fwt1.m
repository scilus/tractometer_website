fw = f;
Jmax = log2(n)-1;
Jmin = 0;
subplot(5,1,1);%
plot(f); axis('tight'); title('Signal');
for j=Jmax:-1:Jmin
    Grossier = subsampling( cconv( fw(1:2^(j+1)), h) );
    Detail = subsampling( cconv( fw(1:2^(j+1)), g) );
    
    fw( 1:2^(j+1) ) = cat( 1, Grossier, Detail );
    j1 = Jmax-j;  
end