% demoShape

[h,g] = compute_wavelet_filter('Haar')
figure
s= 'Ondelettes de Haar';
shape

[h,g] = compute_wavelet_filter('Daubechies', 4)
figure
s='Ondelettes de D4';
shape

[h,g] = compute_wavelet_filter('Daubechies', 6)
figure
s='Ondelettes de D6';
shape

[h,g] = compute_wavelet_filter('Daubechies', 8)
figure
s='Ondelettes de D8';
shape

[h,g] = compute_wavelet_filter('Coiflet', 1)
figure
s='Ondelettes de Coiflet 1';
shape

[h,g] = compute_wavelet_filter('Coiflet', 2)
figure
s='Ondelettes de Coiflet 2';
shape

[h,g] = compute_wavelet_filter('Coiflet', 3)
figure
s='Ondelettes de Coiflet 3';
shape

[h,g] = compute_wavelet_filter('Coiflet', 4)
figure
s='Ondelettes de Coiflet 4';
shape

[h,g] = compute_wavelet_filter('Coiflet', 5)
figure
s='Ondelettes de Coiflet 5';
shape

[h,g] = compute_wavelet_filter('Beylkin')
figure
s='Ondelettes de Beylkin';
shape


[h,g] = compute_wavelet_filter('Vaidyanathan')
figure
s='Ondelettes de Vaidyanathan';
shape


