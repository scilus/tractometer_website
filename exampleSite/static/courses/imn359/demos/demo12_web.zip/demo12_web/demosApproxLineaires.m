
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% APPROXIMATIONS LIN�AIRES DANS DES BASES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load piece_regular.mat;
f = piece_regular;
n = 512;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Approximation dans Fourier
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ft = fftshift(fft(f));
ft_a = zeros(n,1);

m = 128;
sel = (n/2-m/2:n/2+m/2);
size(sel);

ft_a(sel) = ft(sel);    % Approximation lin�aire gardant que les 128 premiers coeffs


%hold
%plot(1:n, abs(ft), 'b');
%plot(1:n, abs(ft_a), 'r');


f1 = ifft(fftshift(ft));
disp(strcat((['Error |f-f1|/|f| using Fourier basis = ' num2str(norm(f-f1)/norm(f))])));

fm = real(ifft(fftshift(ft_a)));
disp(strcat((['Error |f-fm|/|f| using Fourier basis = ' num2str(norm(f-fm)/norm(f))])));


figure(1)
subplot(3,1,1);
plot(f); title('Original signal'); axis 'tight'; %axis([1:n 0 1]);
subplot(3,1,2);
plot(f1); title('Signal from full Fourier spectrum reconstruction'); axis 'tight'; %axis([1:n 0 1]);
subplot(3,1,3);
plot(fm);  title('Approximated signal with m = 128 coefficients'); axis 'tight'; %axis([1:n 0 1]);


 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Approximation avec des cosinus discrets
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fc = dct(f);
fc_a = zeros(n,1);

m = 128;
sel = 1:m;
size(sel);

fc_a(sel) = fc(sel);    % Approximation lin�aire gardant que les 128 premiers coeffs


%hold
%plot(1:n, abs(fc), 'b');
%plot(1:n, abs(fc_a), 'r');


f1 = idct(fc);
disp(strcat((['Error |f-f1|/|f| using a full Discrete Cosine basis = ' num2str(norm(f-f1)/norm(f))])));

fm = idct(fc_a);
disp(strcat((['Error |f-fm|/|f| using a linear Discrete Cosine approximation = ' num2str(norm(f-fm)/norm(f))])));


figure(2)
subplot(3,1,1);
plot(f); title('Original signal'); axis 'tight'; %axis([1:n 0 1]);
subplot(3,1,2);
plot(f1); title('Signal from full DCT reconstruction'); axis 'tight'; %axis([1:n 0 1]);
subplot(3,1,3);
plot(fm);  title('Approximated signal with m = 128 coefficients'); axis 'tight'; %axis([1:n 0 1]);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Approximation avec des cosinus locaux
% 
% Ameliore l'approximation globale de la DCT
% On decoupe le signal en segments locaux (patches en 2D) dans lesquels on
% fait la DCT
%
% JPEG est bas� sur cette base
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
w = 16; % taille du segment

fc_a = zeros(n,1);

% DCT local 
for i=1:n/w
  seli = (i-1)*w+1:i*w;
  
  fc_a(seli) = dct( f(seli) );
end


%hold
%plot(1:n, abs(fc), 'b');
%plot(1:n, abs(fc_a), 'r');


% We have bins of 16 units, so 32 bins over the signal f with n = 512. This
% means that we want to keep 128 coefficients, we keep 4 lowest frequency
% coefficients in each bin

% iDCT local
fm_local = fc_a;
fc_a_4 = zeros(n,1);
fm_a = zeros(n,1);
for i=1:n/w
  seli = (i-1)*w+1:i*w; 
  
  sel_a = (i-1)*w+1:(i-1)*w+4;
  
  fc_a_4(sel_a) = fm_local(sel_a);
  
  fm_local(seli) = idct( fm_local(seli) );
  
  fm_a(seli) = idct( fc_a_4(seli) );
  
end

disp(strcat((['Error |f-f1|/|f| using a full Discrete Cosine basis = ' num2str(norm(f-f1)/norm(f))])));
disp(strcat((['Error |f-f1|/|f| using a full local Discrete Cosine basis = ' num2str(norm(f-fm_local)/norm(f))])));
disp(strcat((['Error |f-fm|/|f| using a linear local Discrete Cosine approximation = ' num2str(norm(f-fm_a)/norm(f))])));

figure(3)
subplot(3,1,1);
plot(fm_local); title('Signal from full local DCT reconstruction'); axis 'tight'; %axis([1:n 0 1]);
subplot(3,1,2);
plot(fm); title('Approximation from m = 128 DCT coefficients'); axis 'tight'; %axis([1:n 0 1]);
subplot(3,1,3);
plot(fm_a);  title('Approximated from m = 128 local DCT coefficient with segments of size 16'); axis 'tight'; %axis([1:n 0 1]);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Approximation avec des ondelettes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Haar 
h = [0 1/sqrt(2) 1/sqrt(2)];
g = [0 1/sqrt(2) -1/sqrt(2)];

fwt1;

ifwt1;
disp(strcat((['Error |f-f1|/|f| using a full Haar wavelet basis = ' num2str(norm(f-f1)/norm(f))])));


subplot(3,1,1);
plot(f); title('Original signal'); axis 'tight'; %axis([1:n 0 1]);
subplot(3,1,2);
plot(f1); title('Signal from full Haar wavelet '); axis 'tight'; %axis([1:n 0 1]);


fw_a = zeros(n,1);

m = 128;
sel = 1:m;
size(sel);

fw_a(sel) = fw(sel);

fw = fw_a;
ifwt1;

disp(strcat((['Error |f-fm|/|f| using a linear Haar wavelet approximation = ' num2str(norm(f-f1)/norm(f))])));


subplot(3,1,3);
plot(f1);  title('Approximated signal with m = 128 Haar wavelet coefficients'); axis 'tight'; %axis([1:n 0 1]);


% D4

h = [ 0    0.4830    0.8365    0.2241   -0.1294 ];
g = [ 0   -0.1294   -0.2241    0.8365   -0.4830 ];


fwt1;

ifwt1;
disp(strcat((['Error |f-f1|/|f| using a full D4 wavelet basis = ' num2str(norm(f-f1)/norm(f))])));

figure(4)
subplot(3,1,1);
plot(f); title('Original signal'); axis 'tight'; %axis([1:n 0 1]);
subplot(3,1,2);
plot(f1); title('Signal from full D4 wavelet '); axis 'tight'; %axis([1:n 0 1]);


fw_a = zeros(n,1);

m = 128;
sel = 1:m;
size(sel);

fw_a(sel) = fw(sel);

fw = fw_a;
ifwt1;

disp(strcat((['Error |f-fm|/|f| using a linear D4 wavelet approximation = ' num2str(norm(f-f1)/norm(f))])));


subplot(3,1,3);
plot(f1);  title('Approximated signal with m = 128 D4 wavelet coefficients'); axis 'tight'; %axis([1:n 0 1]);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Approximation avec des ondelettes biorthogonales
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
options.null = 0;
separable = getoptions(options, 'separable', 0);
options.separable = separable;
% 7/9 wavelets, p = 4 vanishing moments
options.h = getoptions(options, 'filter', '7-9');


fw = perform_wavelet_transf(f, 1, +1, options);

f1 = perform_wavelet_transf(fw, 1, -1, options);
disp(strcat((['Error |f-f1|/|f| using a full 7/9 lifting wavelet basis = ' num2str(norm(f-f1)/norm(f))])));

figure(5)
subplot(3,1,1);
plot(f); title('Original signal'); axis 'tight'; %axis([1:n 0 1]);
subplot(3,1,2);
plot(f1); title('Signal from full 7/9 lifting wavelets '); axis 'tight'; %axis([1:n 0 1]);

fw_a = zeros(n,1);
m = 128;
sel = 1:m;
size(sel);
fw_a(sel) = fw(sel);

f1 = perform_wavelet_transf(fw_a, 1, -1, options);
disp(strcat((['Error |f-fm|/|f| using a linear 7/9 lifting wavelet approximation = ' num2str(norm(f-f1)/norm(f))])));


subplot(3,1,3);
plot(f1);  title('Approximated signal with m = 128, 7/9 lifting wavelet coefficients'); axis 'tight'; %axis([1:n 0 1]);













