
selj = [4:8];
f = [];
k = 0;
for j=selj
    k = k+1;
    
    fw = zeros(n,1);
    p = 1 + 2^j;
    
   
    fw(p) = 1; ifwt2;
    f = f1;
    f = circshift(f,n/2);
    
    subplot(length(selj),1,k); 
    plot(f); 
    axis('tight'); title([s ' Shape at scale 2^j, j=' num2str(selj(k))]);
    axis([1 n min(f(:))*1.05 max(f(:))*1.05]);

end
