function d = delta( t, t0 )

d = zeros(1, length(t));

j = 1;

for i=1:length(t)
    if( j > length(t0) )
        continue;
    else
       
        if( t(i) == t0(j) )
            d(i) =  1.0;
            j = j + 1;
        else
            d(i) = 0.0;
        end
    end
    
end

