%Echantillonnage
load piece_regular_1024;

% C'est comme si on avait echantillonne le signal a tous les 1/1024 pts
% ou 1024 Hz
t = linspace(0,1,1024)
plot(t,f0);

f = linspace(-512,512,1024)
plot(f, abs( fft(f0) ) );

% On voit que la fft est symetrique. En fait, on a que de l'information sur
% 1024/2 frequences a cause des coefficients complexe de la TF
plot(f, abs( fftshift(fft(f0)) ) );

% Qu'est-ce que ca veut dire? Ca veut dire que si nous voulons les
% frequences 'f', il faut au moins echantillonner a 2*f (1/(2*f)) dans le
% monde spatial



%Exemple d'�chantillonnage
t=-2*pi:0.01:2*pi; 

% fr�quence
f0=0.5; 
y=2*sin(2*pi*f0*t);

plot(t,y,'Linewidth', 2);



ts=20;
ii=1:ts:length(t);
t0=t(ii);
d = delta(t,t0); 

plot(d,'Linewidth', 2) % dirac � tous les ts
%plot(abs(fft(d)),'Linewidth', 2) % dirac � tous les pi*ts 


figure;
plot(t,y,'b-',t,d,'ro-','linewidth',2); 
set(gca,'xcolor',[0 0 0],'ycolor',[0 0 0],'FontSize',16);
set(gcf,'Color',[1 1 1],'Position',[280 200 680 500],'InvertHardCopy','off');
xlabel('t');ylabel('Amplitude'); legend('y(t)','\delta(t-nt_s)');axis([-2*pi 2*pi -2.2 2.2]);  

ys=y.*d;t2=t;t2(find(ys==0))=[];
ys(find(ys==0))=[];

figure;
plot(t2,ys,'bo-','linewidth',2); 
set(gca,'xcolor',[0 0 0],'ycolor',[0 0 0],'FontSize',16);
set(gcf,'Color',[1 1 1],'Position',[280 200 680 500],'InvertHardCopy','off');xlabel('t');
ylabel('Amplitude'); legend('y_s(t)');axis([-2*pi 2*pi -2.2 2.2]);  




% Exemple de repliement

t1 = 0:1/1000:1;   % ts = 0.001 second, fs = 1000 
t2 = 0:1/100:1;   % ts = 0.01 second, fs = 100 
t3 = 0:1/20:1;   % ts = 0.05 second, fs = 20 
t4 = 0:1/10:1;   % ts = 0.1 second, fs = 10 

f1 = 8; T1 = 1/f1; % frequence de 8 Hz 
f2 = 3; T2 = 1/f2; % frequence de 3 Hz

s1 = cos(2*pi*f1*t1) + cos(2*pi*f2*t1);
s2 = cos(2*pi*f1*t2) + cos(2*pi*f2*t2);
s3 = cos(2*pi*f1*t3) + cos(2*pi*f2*t3);
s4 = cos(2*pi*f1*t4) + cos(2*pi*f2*t4);


subplot(4,1,1); plot(t1, s1, '-b')
subplot(4,1,2); plot(t2, s2, '-bo')
subplot(4,1,3); plot(t3, s3, '-bo')
subplot(4,1,4); plot(t4, s4, '-bo')

f1 = -500:500;
f2 = -50:50;
f3 = -10:10;
f4 = -5:5;

subplot(4,1,1); plot(f1, abs(fftshift(fft(s1)))); axis( [ -10 10 0 500 ] )
subplot(4,1,2); plot(f2, abs(fftshift(fft(s2)))); axis( [ -10 10 0 100 ] )
subplot(4,1,3); plot(f3, abs(fftshift(fft(s3)))); axis( [ -10 10 0 20 ] )
subplot(4,1,4); plot(f4, abs(fftshift(fft(s4)))); axis( [ -10 10 0 10 ] )




%Exemple de recouvrement
t = -1:0.1:1   % Echantillonne � 10 Hz
a = [0.5 4];
y = a(1)*exp(-a(2)^(2)*t.^2);

fs = -5:0.5:5;
hold on
plot(t, y, '-bo');
plot(fs, abs(fftshift(fft(y))), '-ro');
hold off


t = -1:0.3:1 % �chantillonne � 10/3 Hz
a = [0.5 4];
y = a(1)*exp(-a(2)^(2)*t.^2);


fs = -5:10/length(t):4.9;
hold on
plot(t, y, '-bo');
plot(fs, abs(fftshift(fft(y))), '-ro');
hold off






