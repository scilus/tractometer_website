t1 = 0:1/1000:1;   % ts = 0.001 second, fs = 1000 
f1 = 8; T1 = 1/f1; % frequence de 8 Hz 
f2 = 3; T2 = 1/f2; % frequence de 3 Hz

s1 = cos(2*pi*f1*t1) + cos(2*pi*f2*t1);

figure
subplot(2,1,1); plot(s1)
subplot(2,1,2); plot(dct(s1))


% La DCT
x = (1:100) + 50*cos((1:100)*2*pi/40);
X = dct(x);

subplot(2,1,1); plot(x);
subplot(2,1,2); plot(X);


% Piece-regular
load piece-regular;
subplot(3,1,1);
plot( abs( fft(x0 ) ) ); title('fft of piece regular');
subplot(3,1,2);
plot( abs( fftshift( fft(x0 )) ) ); title('fft shifted of piece regular');
subplot(3,1,3);
plot( dct(x0 )); title('dct of piece regular');


n = 100; %100
xf = fftshift(fft( x0 ));
xc = dct( x0 );
x_compressed = zeros(length(x0),1);
x_compressed(length(x0)/2-50:length(x0)/2+50) = xf(length(x0)/2-50:length(x0)/2+50)

x_dct = zeros(length(x0),1);
x_dct(1:n) = xc(1:n);

subplot(3,1,1);
plot( x0,'linewidth', 3 ); axis 'tight'; title('Piece-regular');
subplot(3,1,2);
plot( abs( ifft(ifftshift(x_compressed))), 'linewidth', 3 ); axis 'tight'; title([ num2str(n) ' Fourier coeffs: erreur: ' ...
    num2str(norm( abs(ifft(ifftshift(x_compressed))) - x0)/norm(x0)*100) '%' ]);
subplot(3,1,3);
plot( idct(x_dct ), 'linewidth', 3); axis 'tight'; title([ num2str(n) ' DCT coeffs: error: ' ...
     num2str(norm(idct(x_dct ) - x0)/norm(x0)*100) '%' ]);



% In 2D
% Fourier classique
load lena.mat;
n = length(M);
m = n/8; 
F = fftshift(fft2(M));
F1 = zeros(n);
sel = (n/2-m/2:n/2+m/2)+1;
F1(sel,sel) = F(sel,sel); 
f1 = real( ifft2(fftshift(F1)) );
% display
subplot(1,2,1); 
imagesc(M); title('Image'); colormap(gray);  axis image; axis off; 
subplot(1,2,2); 
imagesc(f1); colormap(gray);  axis image; axis off; 
title(['Approx, SNR=' num2str(snr(M,f1), 4) 'dB']);

% dct 2D
Mc = dct2(M);
subplot(1,2,1); 
imagesc(log(abs(Mc))); colormap('gray');
subplot(1,2,2); 
imagesc(log(abs(F))); colormap('gray');

f2 = zeros(n,n);
f2(1:m,1:m) = Mc(1:m,1:m);
f2 = idct2(f2);

%subplot(1,3,1); 
%imagesc(M); title('Image'); colormap(gray);  axis image; axis off; 
subplot(1,2,1); 
imagesc(f1); colormap(gray);  axis image; axis off; 
title(['Fourier Approx ' num2str(m^2) ' coeffs, SNR=' num2str(snr(M,f1), 4) 'dB']);
subplot(1,2,2); 
imagesc(f2); colormap(gray);  axis image; axis off; 
title(['DCT Approx ' num2str(m^2) ' coeffs, SNR=' num2str(snr(M,f2), 4) 'dB']);


% DCT locale
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Approximation avec des cosinus locaux
% 
% Ameliore l'approximation globale de la DCT
% On decoupe le signal en segments locaux  dans lesquels on
% fait la DCT
%
% JPEG est bas�e sur cette base
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load piece-regular.mat;
n = length(x0);
fc = dct(x0);
f1 = idct(fc);
coeff = 192;
fm = zeros(n,1);
fm(1:coeff) = fc(1:coeff);
fm = idct(fm);

w = 32; % taille du segment

fc_a = zeros(n,1);

% DCT local 
for i=1:n/w
  seli = (i-1)*w+1:i*w;
  
  fc_a(seli) = dct( x0(seli) );
end


subplot(1,2,1)
plot(1:n, abs(fc), 'b');
subplot(1,2,2)
plot(1:n, abs(fc_a), 'r');


% We have bins of w units, so n/w bins over the signal f with n units. This
% means that if we want to keep coeff coefficients, we keep coeff/(n/w) lowest frequency
% coefficients in each bin

% iDCT local
fm_local = fc_a;
fc_a_4 = zeros(n,1);
fm_a = zeros(n,1);

s = coeff / (n/w);
for i=1:n/w
  seli = (i-1)*w+1:i*w; 
  
  sel_a = (i-1)*w+1:(i-1)*w+s;
  
  fc_a_4(sel_a) = fm_local(sel_a);
  
  fm_local(seli) = idct( fm_local(seli) );
  
  fm_a(seli) = idct( fc_a_4(seli) );
  
end

f = x0;
disp(strcat((['Error |f-f1|/|f| using a full Discrete Cosine basis = ' num2str(norm(f-f1)/norm(f))])));
disp(strcat((['Error |f-f1|/|f| using a full local Discrete Cosine basis = ' num2str(norm(f-fm_local)/norm(f))])));
disp(strcat((['Error |f-f1|/|f| using ' num2str(coeff) ' DCT coeffs = ' num2str(norm(f-fm)/norm(f))])));
disp(strcat((['Error |f-fm|/|f| using ' num2str(coeff) ' local DCT coeffs = ' num2str(norm(f-fm_a)/norm(f))])));

subplot(3,1,1);
plot(fm_local); title('Signal from full local DCT reconstruction'); axis 'tight'; %axis([1:n 0 1]);
subplot(3,1,2);
plot(fm); title(['Approximation from ' num2str(coeff) ' DCT coefficients']); axis 'tight'; %axis([1:n 0 1]);
subplot(3,1,3);
plot(fm_a);  title(['Approximated from ' num2str(coeff) ' DCT coefficient with segments of size ' num2str(w)]); axis 'tight'; %axis([1:n 0 1]);




%%%%%%%%%%%%%%%%%
% Plus agressif %
%%%%%%%%%%%%%%%%%

load piece-regular.mat;
n = length(x0);
fc = dct(x0);
f1 = idct(fc);
coeff = 128;
fm = zeros(n,1);
fm(1:coeff) = fc(1:coeff);
fm = idct(fm);

w = 8; % taille du segment

fc_a = zeros(n,1);

% DCT local 
for i=1:n/w
  seli = (i-1)*w+1:i*w;
  
  fc_a(seli) = dct( x0(seli) );
end


hold
plot(1:n, abs(fc), 'b');
plot(1:n, abs(fc_a), 'r');


% We have bins of 16 units, so 64 bins over the signal f with n = 1024. This
% means that if we want to keep 256 coefficients, we keep 4 lowest frequency
% coefficients in each bin

% iDCT local
fm_local = fc_a;
fc_a_4 = zeros(n,1);
fm_a = zeros(n,1);

s = coeff / (n/w);
for i=1:n/w
  seli = (i-1)*w+1:i*w; 
  
  sel_a = (i-1)*w+1:(i-1)*w+s;
  
  fc_a_4(sel_a) = fm_local(sel_a);
  
  fm_local(seli) = idct( fm_local(seli) );
  
  fm_a(seli) = idct( fc_a_4(seli) );
  
end

f = x0;
disp(strcat((['Error |f-f1|/|f| using a full Discrete Cosine basis = ' num2str(norm(f-f1)/norm(f))])));
disp(strcat((['Error |f-f1|/|f| using a full local Discrete Cosine basis = ' num2str(norm(f-fm_local)/norm(f))])));
disp(strcat((['Error |f-f1|/|f| using ' num2str(coeff) ' DCT coeffs = ' num2str(norm(f-fm)/norm(f))])));
disp(strcat((['Error |f-fm|/|f| using ' num2str(coeff) ' local DCT coeffs = ' num2str(norm(f-fm_a)/norm(f))])));

subplot(3,1,1);
plot(fm_local); title('Signal from full local DCT reconstruction'); axis 'tight'; %axis([1:n 0 1]);
subplot(3,1,2);
plot(fm); title(['Approximation from ' num2str(coeff) ' DCT coefficients']); axis 'tight'; %axis([1:n 0 1]);
subplot(3,1,3);
plot(fm_a);  title(['Approximated from ' num2str(coeff) ' DCT coefficient with segments of size ' num2str(w)]); axis 'tight'; %axis([1:n 0 1]);






