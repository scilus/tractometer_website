import cmath as cm
import matplotlib.pyplot as plt
import numpy as np

# Exemple 1 SF complexe
# f(t) = -2A/pi sum (1 / (4n^2 -1) e^(i2pi*nt))

A = 10
t = np.arange(-3.0, 3.01, 0.01)
f1 = np.abs(A * np.sin(np.pi * t)) # petit truc pour rendre sin periodique de periode T

f = np.zeros(t.shape, dtype=complex)
for n in range(-10, 11):
    for idx, i in enumerate(t):
        f[idx] += (-2 * A / np.pi * (1 / (4 * n * n - 1)) + 0j) * cm.exp(1j * 2 * np.pi * n * i)

plt.plot(t, f, 'b', linewidth=2)
plt.plot(t, f1, 'r', linewidth=2)
plt.savefig('demo04_ex1.jpg')
plt.show()

# Exemple 2 SF complexe
# f(t) = Ad/T sum( sinc( w*n*d / 2) * exp(i*w*n*t);

A = 1
T = 20 # (2 * d)
d = 10
w = 2 * np.pi / T
t = np.arange(-35, 35.1, 0.1)
f = np.zeros(t.shape, dtype=complex)
for n in range(-10, 11):
    arg = w * n * d / 2
    for idx, i in enumerate(t):

        if (arg != 0):
            f[idx] += A * d / T * np.sin(arg) / arg * cm.exp(1j * w * n * i)
        else:
            f[idx] += A * d / T * 1 / cm.exp(1j * w * n * i)

plt.clf()
plt.plot(t, f, linewidth=2)
plt.savefig('demo04_ex2.jpg')
plt.show()

# Spectre d'amplitude
# f(w) = |c_n| for n valeur de w

w = np.arange(-160 * np.pi, 160 * np.pi, 10)
A = 1
T = 1/2
d = 1/20
arg = w * d /2
f = A * d / T * np.sin(arg) / arg

plt.clf()
plt.plot(w, f, '.-', linewidth=2)
plt.savefig('demo04_ex2_amp.jpg')
plt.show()

K = 100000
x = np.arange(-np.pi, np.pi, 0.01)
f = 0
E = np.pi * np.pi / 3

for n in range(1, K):
    f += 2 * pow(-1, n+1) / n * np.sin(n * x)
    E += -2 * 1 / (n * n)

plt.clf()
plt.plot(x, x, 'r', linewidth=2)
plt.plot(x, f, 'b')
plt.legend(('f(x) = x','SF f(x) = sum(n=1)^K 2/n(-1)^(n+1)sin(nt) with n = {}'.format(str(K))))
plt.title('Nombre d harmoniques n = {}'.format(str(K)) + ', Erreur quadratique E_k {}'.format(str(E)))
plt.savefig('demo04_ex2_erreur.jpg')
plt.show()

err = 1 / len(x) * np.linalg.norm(x - f)
print('Erreur quadratique numerique = {}'.format(err))
print('E = {}'.format(E))

# Gibbs ringing
x = np.arange(-20, 20.1, 0.1)

f = 3/2

for n in range(1, 51):
    f += 3 * (1 - np.cos(n * np.pi)) / (n * np.pi) * np.sin(n * np.pi * x / 5)

plt.clf()
plt.plot(x, f, linewidth=2)
plt.savefig('demo04_gibbs.jpg')
plt.show()

