import cmath as cm
import matplotlib.pyplot as plt
import numpy as np
from scipy.io import loadmat


E = [[1, 1, 1, 1],
     [1, -1j, -1, 1j],
     [1, -1, 1, -1],
     [1, 1j, -1, -1j]]

g = [0, 1, 2, 3]

# TDF
G = np.dot(E, g)
print(G)

# iTDF
g3 = np.dot(G, np.conj(E))
print(g3)

g4 = np.fft.fft(g)
print(g4)


from scipy.fft import fft, fftshift 
g = loadmat("piece_regular.mat")['piece_regular']
g = g.squeeze()
G = fft(g)
t = np.linspace(0, 1, np.shape(g)[0])
f = np.linspace(-256, 256, 512)
plt.plot(t, g)
plt.savefig('demo05_fft_raw.jpg')
plt.show()

plt.plot(f, np.real(G))
plt.savefig('demo05_real_fft.jpg')
plt.show()

plt.plot(f, np.real(fftshift(G)))
plt.savefig('demo05_real_fftshift.jpg')
plt.show()

plt.plot(f, np.imag(fftshift(G)))
plt.savefig('demo05_imag_fftshift.jpg')
plt.show()

plt.plot(f, np.abs(fftshift(G)))
plt.savefig('demo05_abs_fftshift.jpg')
plt.show()
